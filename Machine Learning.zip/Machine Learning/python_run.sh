#!/usr/bin/env bash
python3 driver.py &
python3 gcp.py &